% clear all

function frequency_area_plots_cluster

load('Two_Area_Inputs_Cap_RLoad_RGen.mat')


exten = ['C:\Users\Maldon\OneDrive - Queen Mary, University of London\Matlab Files\full battery models\Gaussian MCMC Bat\TWO AREA MODELS\TwoAreaModels\Comparative Two Area MCMC\Generation Battery Sampled AGC\fequency charts'];
%exten = ['C:\Users\Maldon\OneDrive - Queen Mary, University of London\Matlab Files\full battery models\Gaussian MCMC Bat\TWO AREA MODELS\TwoAreaModels\Comparative Two Area MCMC\Load Battery Simulations\cluster results\charts'];

power = [7.8350    7.8350    7.3350    7.3350    9.6700   17.6700]*100;

k = 0;

sig2 = @(stdv,corr,ND)ones(ND,ND)*(corr*stdv)+diag(ones(1,ND)*(stdv-corr*stdv));

kk = ones(1,2);
bat_list = 0:1:10;
Disturbance_Location = 2


for i = 1:length(bat_list)
bat_cap_list{i} = kk*bat_list(i);
end

st_dev = 0.003;
sig_off_diag = [0 0.2 0.4 0.6 0.8 0.99];

u=0;
for i = 1:length(sig_off_diag)
    for j = 1:length(bat_cap_list)
        u = u +1;
        pairs{u} = [u, sig_off_diag(i), bat_cap_list{j}];
    end
end

for j = 1:length(sig_off_diag)
    f.(['f2',num2str(j)]) = figure('Units','normalized');
    set(f.(['f2',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);

for i = 1:length(bat_cap_list)
f.(['f1',num2str(i)]) = figure('Units','normalized');
set(f.(['f1',num2str(i)]),'Units','Normalized','OuterPosition',[0 0 1 1]);

k = k+1;
    
if Disturbance_Location==1
    NR = 4;
    dist_location = Local_Gens;
    label = ['Gen_Dist'];
elseif Disturbance_Location ==2
    NR = 2;
    dist_location = Local_Load;
    label = ['Load_Dist'];
else
    NR = 6;
    dist_location = logical(Local_Load+Local_Gens);
    label = ['Full_Dist'];
end

pairs{u} = [u, sig_off_diag(i), bat_cap_list{j}];
max_battery = pairs{k}(3:end);                %this should be the same dimension as battery_location and outlines the size of the battery at each node in per unit form
off_diag = pairs{k}(2);
sigma = sig2(st_dev,off_diag,NR);
n1 = num2str(max_battery(1)*100);
cova = num2str(sigma(1,2)*10);        

    
y=load(['covariance_',cova,'_',n1,'MW_BatFreq_Reg',label,'.mat'],'FRb');

     extremeevents = y.FRb.(['D',n1]);
     BAT_ROU_Sequence= y.FRb.(['BatSequence',n1]);
     BAT_Nodal_Activation= y.FRb.(['BatNodeAct',n1]);
     AGC_Time = y.FRb.(['AGC_Initial_Time',n1]);
     Pre_Contin_Battery = y.FRb.(['Initial_Bat',n1]);
     BAT_Dynamics = y.FRb.(['Bat_Dynamics',n1]);
     BAT_Frequency_Test = y.FRb.(['Bat_Freq_Test',n1]);
     
for ii = 1:length(BAT_Dynamics)
    
freq = BAT_Dynamics{ii}(:,2:7);
of = freq - 60.15;
of(of<-0.01) = 0;
uf = freq - 59.85;
uf(uf>0.01) = 0;
t = BAT_Dynamics{ii}(:,1);
dist_power = extremeevents(ii,:).*power(1:NR);
Area_Node_Raw(ii,:) = (trapz(t,abs(of),1) + trapz(t,abs(uf),1));
Area_Node_Adj(ii,:) = (trapz(t,abs(of),1) + trapz(t,abs(uf),1))./abs(sum(dist_power));
Area_Node_Abs_Adj(ii,:) = (trapz(t,abs(of),1) + trapz(t,abs(uf),1))./sum(abs(dist_power));

end
Frequency_Area{i} = Area_Node_Raw;
Nodal_mean_Area_Raw(i,:,j)= mean(Area_Node_Raw,'omitNaN');
Nodal_mean_Area_Adj(i,:,j)= mean(Area_Node_Adj,'omitNaN');
Nodal_mean_Area_Abs_Adj(i,:,j)= mean(Area_Node_Abs_Adj,'omitNaN');

system_mean_area_raw(j,i) = mean(Area_Node_Raw,'all','omitNaN');
system_mean_area_Adj(j,i) = mean(Area_Node_Adj,'all','omitNaN');
system_mean_area_Abs_Adj(j,i) = mean(Area_Node_Abs_Adj,'all','omitNaN');

% figure(f.(['f1',num2str(i)]))
% sgtitle([num2str(agc_plot_list(i)),'s AGC Signal; Distribution of Nodal Frequency Excursion Areas $', chart_label,'$'],'interpreter','latex');
% 
% for ii = 1:6
%     subplot(2,3,ii)
%     histogram(Frequency_Area{i}(:,ii),'FaceColor','blue','normalization','probability','NumBins',10);
%     grid on
%     xlabel('X = FEA');
%     ylabel('P(X)');
%     title(['Node- ',num2str(ii)],'interpreter','latex');
%     legend('FEA')
% end
% 
%  fea_HIST= ['FEA Histogram ',num2str(agc_plot_list(i)),'s AGC Signal ',chart_label,'.jpg'];
%  saveas(f.(['f1',num2str(i)]),[exten,'/',fea_HIST])
%  close(f.(['f1',num2str(i)]));
 
end

% figure(f.(['f2',num2str(j)]))
% sgtitle(['Frequency Excursion Areas FEA for Nodes and System- ',chart_label],'interpreter','latex')
% 
%     subplot(2,3,1)
%     plot(bat_list,Nodal_mean_Area_Raw(:,:,j),'LineWidth',2);
%     title(['Nodal Average FEA ',chart_label],'interpreter','latex');
%     legend('Node 1','Node 2','Node 3','Node 4','Node 5','Node 6','interpreter','latex')
%     xlabel('AGC Signal, s','interpreter','latex')
%     ylabel('FEA','interpreter','latex')
%     grid on
% 
%     subplot(2,3,2)
%     plot(bat_list,Nodal_mean_Area_Abs_Adj(:,:,j),'LineWidth',2);
%     title({'Nodal Average FEA ','per Total Abs Disturbance $\frac{FEA}{\sum_i |u_i|}$'},'interpreter','latex');
%     legend('Node 1','Node 2','Node 3','Node 4','Node 5','Node 6','interpreter','latex')
%     xlabel('AGC Signal, s','interpreter','latex')
%     ylabel('Adj FEA/MW: $\frac{FEA}{\sum_i |u_i|}$','interpreter','latex')
%     grid on
% 
%     subplot(2,3,3)
%     plot(agc_plot_list,Nodal_mean_Area_Adj(:,:,j),'LineWidth',2);
%     title({'Nodal Average FEA','per MW Abs Total Disturbance: $\frac{FEA}{|\sum_i u_i|}$'},'interpreter','latex');
%     legend('Node 1','Node 2','Node 3','Node 4','Node 5','Node 6','interpreter','latex')
%     xlabel('AGC Signal, s','interpreter','latex')
%     ylabel('Adj2 FEA/MW: $\frac{FEA}{|\sum_i u_i|}$','interpreter','latex')
%     grid on
% 
%     subplot(2,3,4)
%     plot(agc_plot_list,system_mean_area_raw(j,:),'LineWidth',2);
%     xlabel('AGC Signal, s','interpreter','latex');
%     ylabel('Avg\_FEA','interpreter','latex');
%     title('System Average FEA vs AGC Signal','interpreter','latex')
%     grid on
% 
%     subplot(2,3,5)
%     plot(agc_plot_list,system_mean_area_Adj(j,:),'LineWidth',2);
%     xlabel('AGC Signal, s','interpreter','latex');
%     ylabel('Avg\_Adj\_FEA','interpreter','latex');
%     title({'System Average FEA ',' Adjusted by total Disturbance: $\frac{FEA}{|\sum_i u_i|}$ vs Battery Power'},'interpreter','latex')
%     grid on
% 
%     subplot(2,3,6)
%     plot(agc_plot_list,system_mean_area_Abs_Adj(j,:),'LineWidth',2);
%     xlabel('AGC Signal, s','interpreter','latex');
%     ylabel('Avg\_Abs\_Adj\_FEA','interpreter','latex');
%     title({'System Average FEA ',' Adjusted by total Absolute Disturbance: $\frac{FEA}{\sum_i |u_i|}$ vs Battery Power'},'interpreter','latex')
%     grid on
% 
%     fea_vs_bat_Node = ['Nodal and Network Average FEA vs AGC Signal ',chart_label,'.jpg'];
%     saveas(f.(['f2',num2str(j)]),[exten,'/',fea_vs_bat_Node]);
%     close(f.(['f2',num2str(j)]));
end


end
