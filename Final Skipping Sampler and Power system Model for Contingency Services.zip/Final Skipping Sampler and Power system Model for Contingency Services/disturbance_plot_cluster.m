function disturbance_plot_cluster

%clear all

% exten = ['/data/home/ahw493/transaction A/Load Battery Simulations/disturbance plots'];
 exten = ['C:\Users\Maldon\OneDrive - Queen Mary, University of London\Matlab Files\full battery models\Gaussian MCMC Bat\TWO AREA MODELS\TwoAreaModels\Comparative Two Area MCMC\Generation Battery Sampled AGC\disturbance plots'];
k = 0;

kk = ones(1,4);
bat_cap_list = {kk};
agc_list = {0.5 1 1.5 2 2.5 3 4.5 5};
agc_plot_list = [0.5 1 1.5 2 2.5 3 4.5 5];
dist_loc_list = {1,3};

u=0;
for i = 1:length(dist_loc_list)
    
    for j = 1:length(agc_list)
    u = u +1;
    pairs{u} = [u dist_loc_list{i}, agc_list{j}];
    end
        
end


chart_label1 ={'Generator Disturbance','Load Disturbance','All Nodes Disturbance'};
for j = 1:length(dist_loc_list)
    
graph.(['f1',num2str(j)]) = figure('Units','normalized'); set(graph.(['f1',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
Nodal_total_mean = [];
sgtitle(['Nodes which experienced largest frequency deviation ',chart_label1{j}],'interpreter','latex')

for i = 1:length(agc_plot_list)
    
k = k+1;
    
if pairs{k}(2)==1
    NR = 4;
    label = ['Gen_Dist'];
    chart_label = ['Generator Disturbance'];
    spos = [1 2 6 7];
    rowcols = [2 5];
    bpos = {[3 8],[4,9],[5 10]};
elseif pairs{k}(2) ==2
    NR = 2;
    label = ['Load_Dist'];
    chart_label = ['Load Disturbance'];
    rowcols = [2 4];
    spos = [1 5];
    bpos = {[2 6],[3,7],[4 8]};
else
    NR = 6;
    label = ['Full_Dist'];
    chart_label = ['All Nodes Disturbance'];
    rowcols = [3 5];
    spos = [1 2 6 7 11 12];
    bpos = {[3 8 13 ],[4,9 14],[5 10 15]};
end

agc_interval = pairs{k}(3);

n_label = num2str(agc_interval);
n1 = num2str(agc_interval*10);

y=load(['AGC Interval-',n1,'MW_BatFreq_Reg',label,'.mat'],'FRb');

     extremeevents = y.FRb.(['D',n1]);
     BAT_ROU_Sequence= y.FRb.(['BatSequence',n1]);
     BAT_Nodal_Activation= y.FRb.(['BatNodeAct',n1]);
     AGC_Time = y.FRb.(['AGC_Initial_Time',n1]);
     Pre_Contin_Battery = y.FRb.(['Initial_Bat',n1]);
     BAT_Dynamics = y.FRb.(['Bat_Dynamics',n1]);
     BAT_Frequency_Test = y.FRb.(['Bat_Freq_Test',n1]);

mean_list(j,i) = mean(extremeevents,'all');
abs_mean_list(j,i) = mean(abs(extremeevents),'all');

Neg_Mean_list(j,i) = mean(extremeevents(extremeevents<0),'all');
stNM = isnan(Neg_Mean_list(j,i));
Pos_Mean_list(j,i) = mean(extremeevents(extremeevents>=0),'all');
stPM =  isnan(Pos_Mean_list(j,i));
Nodal_total_mean(i,:,j) = mean(extremeevents);

graph.(['f2',num2str(i) num2str(j)]) = figure('Units','normalized'); set(graph.(['f2',num2str(i) num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
figure(graph.(['f2',num2str(i) num2str(j)]))
sgtitle([n_label,'s AGC Signal: Nodal and All Network Distribution of Distubances Associated with Frequency Excursion ',chart_label],'interpreter','latex');
for ii = 1:NR
    
    Nodal_Neg_mean(ii,i,j) = mean(extremeevents(extremeevents(:,ii)<0,ii),'omitNaN');
    Nodal_Pos_mean(ii,i,j) = mean(extremeevents(extremeevents(:,ii)>=0,ii),'omitNaN');
    siN = isnan(Nodal_Neg_mean(ii,i,j));
    siP = isnan(Nodal_Pos_mean(ii,i,j));
    
    subplot(rowcols(1),rowcols(2),spos(ii))
    s = histogram(extremeevents(:,ii),'FaceColor','b','Normalization','probability','NumBin',20);
    grid on 
    
    if siN<1
        xline(Nodal_Neg_mean(ii,i,j),'--r','LineWidth',1.2,'label','Negative Mean','LabelHorizontalAlignment','left')
    end
    
    if siP<1
        xline(Nodal_Pos_mean(ii,i,j),'--g','LineWidth',1.2,'label','Positive Mean','LabelHorizontalAlignment','right')
    end
    
    xline(Nodal_total_mean(i,ii,j),'--k','LineWidth',1.2,'label','Total Mean','LabelHorizontalAlignment','center')

    title(['Node ',num2str(ii)],'interpreter','latex');
    xlabel(['$u_',num2str(ii),'$'],'interpreter','latex');
    ylabel('P(u)','interpreter','latex')
end

figure(graph.(['f2',num2str(i) num2str(j)]));

subplot(rowcols(1),rowcols(2),bpos{1})
s = histogram(extremeevents,'FaceColor','b','Normalization','probability','NumBin',20);
if stNM<1
    xline(Neg_Mean_list(j,i),'--r','LineWidth',1.2,'label','Negative Mean','LabelHorizontalAlignment','left')
end

if stPM<1
    xline(Pos_Mean_list(j,i),'--g','LineWidth',1.2,'label','Positive Mean','LabelHorizontalAlignment','right')
end
xline(mean_list(j,i),'--k','LineWidth',1.2,'label','Total Mean','LabelHorizontalAlignment','center')
grid on
xlabel('u')
ylabel('P(u)')
title({'Distribution of ALL $u$ conditioned',' on frequency excursion'},'interpreter','latex')
legend(s,'u')

subplot(rowcols(1),rowcols(2),bpos{2})
s=histogram(abs(extremeevents),'Facecolor','b','Normalization','probability','NumBins',20)
grid on
xline(abs_mean_list(j,i),'--k','LineWidth',1.2,'label','abs Mean','LabelHorizontalAlignment','center')
xlabel('$|u|$','interpreter','latex');
ylabel('$P(|u|)$','interpreter','latex');
legend(s,'$|u|$','interpreter','latex');
title({'Distribution of ALL $|u|$ conditioned',' on frequency excursion'},'interpreter','latex')

subplot(rowcols(1),rowcols(2),bpos{3})
s = histogram(nonzeros(Pre_Contin_Battery*100),'Normalization','probability','NumBins',20)
grid on
xlabel('$P_{bat,0}$; MW','interpreter','latex')
ylabel('$\textbf{P}[P_{bat,0}]$','interpreter','latex')
title({'Distribution of ','Battery Initial Condition'},'interpreter','latex')
legend(s,'$u$','interpreter','latex');

 Node_HIST= ['Nodal Disturbance Histogram ',num2str(agc_plot_list(i)),'s AGC; ',label,'.jpg'];
 saveas(graph.(['f2',num2str(i) num2str(j)]),[exten,'/',Node_HIST])
 close(graph.(['f2',num2str(i) num2str(j)]));
 
for l = 1:length(BAT_Dynamics)
max_freq(l,:) = max(BAT_Dynamics{l}(:,2:7));
min_freq(l,:) = min(BAT_Dynamics{l}(:,2:7));
end

extreme_freq_location = sum(ismember(max_freq,max(max_freq,[],2))) + ...
    sum(ismember(min_freq,min(min_freq,[],2)));

avg_max_freq_bat(j,i) = mean(max(max_freq,[],2));
avg_min_freq_bat(j,i) = mean(min(min_freq,[],2));

figure(graph.(['f1',num2str(j)])) 

subplot(2,4,i)
bar(extreme_freq_location/sum(extreme_freq_location))
grid on
xlabel('Node','interpreter','latex')
ylabel({'Prob. of most ','extreme freq'},'interpreter','latex')
title([n_label,'MW ;',chart_label],'interpreter','latex')

mean_freq_range(j,i) = mean( max(max_freq,[],2) - min(min_freq,[],2));

end

 idontknow= ['Nodal Extreme Frequency Distribution ',label,'.jpg'];
 saveas(graph.(['f1',num2str(j)]),[exten,'/',idontknow])
 close(graph.(['f1',num2str(j)]));
 
 
    Nodal_Neg_mean(ii,i,j) = mean(extremeevents(extremeevents(:,ii)<0,ii));
    Nodal_Pos_mean(ii,i,j) = mean(extremeevents(extremeevents(:,ii)>=0,ii));
    
   graph.(['f4',num2str(j)]) = figure('Units','normalized'); set(graph.(['f4',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
       sgtitle(['Nodal Statistics for all Disturbance vs AGC Signal Timing: ',chart_label],'interpreter','latex');

        figure(graph.(['f4',num2str(j)]))

    for ii = 1:NR

        subplot(3,NR,ii)
        plot(agc_plot_list,Nodal_total_mean(:,ii,j),'LineWidth',2);
        xlabel('AGC Signal, s','interpreter','latex');
        ylabel(['$\mu(u_{',num2str(ii),'})$'],'interpreter','latex');
        title(['Total Mean: Node ',num2str(ii)],'interpreter','latex');
        grid on

        subplot(3,NR,ii+NR)
        plot(agc_plot_list,Nodal_Neg_mean(ii,:,j),'LineWidth',2);
        xlabel('AGC Signal, s','interpreter','latex');
        ylabel(['$\mu(u_{',num2str(ii),'}<0)$'],'interpreter','latex');
        title(['Negative Mean: Node ',num2str(ii)],'interpreter','latex');   
        grid on

        subplot(3,NR,ii+2*NR)
        plot(agc_plot_list,Nodal_Pos_mean(ii,:,j),'LineWidth',2);
        xlabel('AGC Signal, s','interpreter','latex');
        ylabel(['$\mu(u_{',num2str(ii),'}\ge 0)$'],'interpreter','latex');
        title(['Positive Mean: Node ',num2str(ii)],'interpreter','latex'); 
        grid on
    end

 nodemeanbat= ['Nodal Mean Dist vs AGC Signal ',label,'.jpg'];
 saveas(graph.(['f4',num2str(j)]),[exten,'/',nodemeanbat])
 close(graph.(['f4',num2str(j)]));

graph.(['f7',num2str(j)]) = figure('Units','normalized'); set(graph.(['f7',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
   sgtitle(['Network Disturbance Statistics vs AGC Signal TIming : ',chart_label],'interpreter','latex');
    
figure(graph.(['f7',num2str(j)]))
subplot(2,3,2)
plot(agc_plot_list,abs_mean_list(j,:),'LineWidth',2)
xlabel('AGC Signal, s','interpreter','latex');
ylabel('$\mu(|u|)$','interpreter','latex')
title('Mean Abs Dist vs AGC Timnig','interpreter','latex')
legend('$\mu(|u|)$','interpreter','latex');%,'All\_Node\_Dist')
grid on

subplot(2,3,[1 4])
plot(agc_plot_list,mean_list(j,:),'LineWidth',2)
xlabel('AGC Signal, s','interpreter','latex');
ylabel('$\mu(u)$','interpreter','latex')
title('Mean of Total Dist vs AGC Timnig','interpreter','latex')
legend('$\mu(u)$','interpreter','latex')
grid on

subplot(2,3,5)
plot(agc_plot_list,Neg_Mean_list(j,:),'LineWidth',2);
xlabel('AGC Signal, s','interpreter','latex');
ylabel('$\mu(u<0)$','interpreter','latex');
title(['Mean of Negative Dist vs AGC Timnig '],'interpreter','latex');
grid on
legend('$\mu(u <0)$','interpreter','latex');

subplot(2,3,3)
plot(agc_plot_list,Pos_Mean_list(j,:),'LineWidth',2);
        xlabel('AGC Signal, s','interpreter','latex');
ylabel('$\mu(u>0)$','interpreter','latex');
title(['Mean of Positive Dist vs Battery  '],'interpreter','latex');
grid on
legend('$\mu(u\le 0)$','interpreter','latex');

subplot(2,3,6)
plot(agc_plot_list,mean_freq_range(j,:),'LineWidth',2)
        xlabel('AGC Signal, s','interpreter','latex');
ylabel('frequency Range','interpreter','latex')
title(['Sample Average Frequency Range vs AGC Timnig;'],'interpreter','latex')
legend('$\mu(\max(u)- \min(u))$','interpreter','latex')
grid on

 networkmeanbat= ['Network Disturbance Statistics vs AGC Interval ',label,'.jpg'];
 saveas(graph.(['f7',num2str(j)]),[exten,'/',networkmeanbat])
 close(graph.(['f7',num2str(j)]));
 
end

end