function MCMC_Code_Freq_Reg_Bat_Only(qq,start,label,sigma,NR,NN,number,Be,Be_Fault,Local_Gens,Local_Load,M,power,qa,initial_value,...
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...   %vector of battery location in the network
                    nom_freq_range,...
                    dist_location...
                    )

n = num2str(max_battery(1)*100);
cova = num2str(sigma(1,2)*10);           
if start ==1
     
     y=load(['covariance_',cova,'_',n,'MW_BatFreq_Reg',label,'.mat'],'FRb');

     extremeevents = y.FRb.(['D',n]);
     current_dist = extremeevents(end,:);
     BAT_ROU_Sequence= y.FRb.(['BatSequence',n]);
     BAT_Nodal_Activation= y.FRb.(['BatNodeAct',n]);
     AGC_Time = y.FRb.(['AGC_Initial_Time',n]);
     Pre_Contin_Battery = y.FRb.(['Initial_Bat',n]);
     BAT_Dynamics = y.FRb.(['Bat_Dynamics',n]);
     BAT_Frequency_Test = y.FRb.(['Bat_Freq_Test',n]);
     scale = y.FRb.(['ScaleRate',n])(1);
     rate =  y.FRb.(['ScaleRate',n])(2);
   
else
     current_dist = initial_value;
     extremeevents=[];
     BAT_Nodal_Activation= [];
     BAT_ROU_Sequence= [];
     AGC_Time = [];
     Pre_Contin_Battery = [];
     BAT_Dynamics = {};
     BAT_Frequency_Test = [];
     scale = 1;
     rate = 0.2;
end

jj = 0;
e = 0;
b_counter = 0;
block_rate = 0;
block_j= 0;

for i = 1:number
    
b_counter = b_counter+1;
limitcounter = 1;
aa = 0.5;
prop_dist = mvnrnd(current_dist,aa*sigma);
proposeddirection = prop_dist - current_dist;
unitdistance = proposeddirection/norm(proposeddirection);
k = 6;

while limitcounter <= k
    
    chisqr = chi2rnd(NR,1);
    proposeddistance = ((proposeddirection*inv(aa*sigma)*proposeddirection')^-0.5)*sqrt(chisqr);
    prop_dist = prop_dist + (limitcounter >1)*proposeddistance*unitdistance;
    
    if (sum(prop_dist>0.25) || sum(prop_dist<-0.25))>0
        Region = 0;
        break
    end
    
r = rand(1,7);

         [~,...         % BINARY: test for under frequency load shedding during simulation
          BAT_Extreme_Frequency_Test,...
          BAT_sequence,...          % 20 X 16 array of protection system activations
          BAT_NodalFailure,...      % 4 X 6 array of protection system ativations at each node
          BAT_Dynamics_TFVGBR,...   %list of Frequency, Voltage Governor Battery and ROCOF dynamics 
          Time_to_AGC,...       %this is the time until the next agc signal
          Initial_Battery...    % this is the initial battery output
 ] = Two_Area_Battery_Model(...
                    prop_dist,...       % this is the disturbance vector from the MCMC
                    Be,...              % normal b matrix
                    Be_Fault,...        %faulted B-matrix in case of line trip
                    M,...               % generator/motor inertia
                    Local_Gens,...          % location of generators 
                    Local_Load,...          % location of loads
                    power,...          % pre-contingency power vector
                    NN,...            %number of nodes
                    NR,...            %number of loads
                    qa,...            %initial conditions for dynamical system
                    max_battery,...        %vector of battery maximum power outputs/inputs
                    battery_location,...   %vector of battery location in the network
                    nom_freq_range,...  %nominal frequency range
                    r,...                %random values for agc time and intial battery output
                    dist_location...        %the location of the disturbances (loads or generators)
                    ) ;
                              
    if BAT_Extreme_Frequency_Test(1) > 0 

         Region = 1;
        break
    else
        Region = 0;
    end
    limitcounter = limitcounter+1;
end

accept = mvnpdf(prop_dist',zeros(NR,1),sigma)*Region/mvnpdf(current_dist',zeros(NR,1),sigma);

if accept > rand()
    
    jj = jj+1;
    block_j = block_j+1;

    current_dist = prop_dist;
    extremeevents(end+1,:) = prop_dist;
    BAT_ROU_Sequence(:,:,end+1) = BAT_sequence;
    BAT_Nodal_Activation(:,:,end+1) = BAT_NodalFailure;
    BAT_Dynamics{end+1} = BAT_Dynamics_TFVGBR;
    BAT_Frequency_Test(:,end+1) = BAT_Extreme_Frequency_Test;
    AGC_Time(end+1) = Time_to_AGC;
    Pre_Contin_Battery(:,end+1) = Initial_Battery;
end
    rate = jj/i;
    
end
save_MCMC_Freq_Reg_Bat_Only(...
        extremeevents,...
        BAT_ROU_Sequence,...
        BAT_Nodal_Activation,...
        BAT_Dynamics,...
        AGC_Time,...       %this is the time until the next agc signal
        Pre_Contin_Battery,...  
        label,...
        BAT_Frequency_Test,...
        n,...
        [scale,rate],...
        cova...
        );
end


function [scale, e] = AutoTune(scale, rate, e)

scale = max(0.0001,scale-(0.20-rate)*0.1);

if scale < 0.0005 && rate == 0
    e = e+1;
else
    e = 0;
end

if e>10
    scale = 0.5;
    e=0;
end

end

