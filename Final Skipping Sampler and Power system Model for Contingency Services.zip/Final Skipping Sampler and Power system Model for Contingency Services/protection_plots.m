function protection_plots
%clear all

exten = ['C:\Users\Maldon\OneDrive - Queen Mary, University of London\Matlab Files\full battery models\Gaussian MCMC Bat\TWO AREA MODELS\TwoAreaModels\Comparative Two Area MCMC\Generation Battery Sampled AGC\protection plots'];
% exten = ['/data/home/ahw493/transaction A/Load Battery Simulations/protection charts'];

power = [7.8350    7.8350    7.3350    7.3350    9.6700   17.6700];
k = 0;

kk = ones(1,4);
bat_cap_list = {kk};
agc_list = {0.5 1 1.5 2 2.5 3 4.5 5};
dist_loc_list = {1,3};
agc_plot_list = [0.5 1 1.5 2 2.5 3 4.5 5];

u=0;
for i = 1:length(dist_loc_list)
    
    for j = 1:length(agc_list)
    u = u +1;
    pairs{u} = [u dist_loc_list{i}, agc_list{j}];
    end
        
end

graph.f6 = figure('Units','normalized');set(graph.f6,'Units','Normalized','OuterPosition',[0 0 1 1]);
sgtitle('Cascade Size vs AGC Signal Interval;','interpreter','latex');

for j = 1:length(dist_loc_list)
    
    if j==1
        chart_label = ['Generator Disturbance'];
    elseif j==2
        chart_label = ['Load Disturbance'];
    else
        chart_label = ['All Nodes Disturbance'];
    end

    graph.(['f1',num2str(j)]) = figure('Units','normalized');set(graph.(['f1',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
    sgtitle(['Probability of Protection System Activations at each Node',chart_label],'interpreter','latex');

   graph.(['f2',num2str(j)]) = figure('Units','normalized');set(graph.(['f2',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
   sgtitle(['Probability of Activations at each Node',chart_label],'interpreter','latex');

   graph.(['f3',num2str(j)]) = figure('Units','normalized');set(graph.(['f3',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
   sgtitle(['Distribution of the Number of Protection Sytsem Activations in the Network',chart_label],'interpreter','latex');

   graph.(['f4',num2str(j)]) = figure('Units','normalized');set(graph.(['f4',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
   sgtitle(['Probability of ROCOF Activations',chart_label],'interpreter','latex');

   graph.(['f5',num2str(j)]) = figure('Units','normalized');set(graph.(['f5',num2str(j)]),'Units','Normalized','OuterPosition',[0 0 1 1]);
   sgtitle(['Probability of Cascade Size of UFLS in the Network',chart_label],'interpreter','latex');
   
for i = 1:length(agc_plot_list)

k = k+1;
    
if pairs{k}(2)==1
    NR = 4;
    label = ['Gen_Dist'];
    chart_label = ['Generator Disturbance'];

elseif pairs{k}(2) ==2
    NR = 2;
    label = ['Load_Dist'];
    chart_label = ['Load Disturbance'];

else
    NR = 6;
    label = ['Full_Dist'];
    chart_label = ['All Nodes Disturbance'];

end

agc_interval = pairs{k}(3);
n_label = num2str(agc_interval);
n = num2str(agc_interval*10);

y=load(['AGC Interval-',n,'MW_BatFreq_Reg',label,'.mat'],'FRb');

Sequence= y.FRb.(['BatSequence',n]);
Node= y.FRb.(['BatNodeAct',n]);

nodal_total_act_list = permute(Node(4,:,:),[3 2 1]);
num_samples = length(nodal_total_act_list);


simulation_nodal_total_act_list = sum(nodal_total_act_list);
prob_nodal_total_act = simulation_nodal_total_act_list/num_samples;

figure(graph.(['f1',num2str(j)]));
subplot(2,4,i)
bar(prob_nodal_total_act);
grid on
xlabel('Node','interpreter','latex');
ylabel('Prob','interpreter','latex');
title([n_label,'s; AGC'],'interpreter','latex');



network_total_act_list = sum(nodal_total_act_list,2);
nodal_average_act = mean(nodal_total_act_list);
network_average_act(j,i) = mean(network_total_act_list);


nodal_ROCOF_list = permute(Node(1,:,:),[3 2 1]);
nodal_OFGS_list = permute(Node(2,:,:),[3 2 1]);
nodal_UFLS_Total_list = permute(Node(3,:,:),[3 2 1]);

nodal_UFLS1_list = permute(Node(3,:,:),[3 2 1])==1;
nodal_UFLS2_list = permute(Node(3,:,:),[3 2 1])==2;
nodal_UFLS3_list = permute(Node(3,:,:),[3 2 1])==3;
nodal_UFLS4_list = permute(Node(3,:,:),[3 2 1])==4;

nodal_ROCOF_prob = sum(nodal_ROCOF_list)/num_samples;
nodal_OFGS_prob  = sum(nodal_OFGS_list)/num_samples;
nodal_UFLS1_prob = sum(nodal_UFLS1_list)/num_samples;
nodal_UFLS2_prob = sum(nodal_UFLS2_list)/num_samples;
nodal_UFLS3_prob = sum(nodal_UFLS3_list)/num_samples;
nodal_UFLS4_prob = sum(nodal_UFLS4_list)/num_samples;

       nodal_act_prob = [nodal_ROCOF_prob;...
           nodal_OFGS_prob;...
           nodal_UFLS1_prob;...
           nodal_UFLS2_prob;...
           nodal_UFLS3_prob;...
           nodal_UFLS4_prob];
       
figure(graph.(['f2',num2str(j)]));

subplot(2,4,i)
y = bar([1 2 3 4 5 6],nodal_act_prob');
title([n_label,'s, AGC'],'interpreter','latex');
xlabel('Node','interpreter','latex');
ylabel('prob','interpreter','latex');
if i ==length(agc_plot_list)
legend('rocof','ofgs','1 ufls','2 ufls','3 ufls','4 ufls','interpreter','latex','NumColumns',3);
end
grid on;
       
network_rocof_list =sum(nodal_ROCOF_list,2)>0;
network_ofgs_list = sum(nodal_OFGS_list,2)>0;
network_ufls_total_list = sum(nodal_UFLS_Total_list,2);
    network_total_act_prob  = sum([network_rocof_list network_ofgs_list network_ufls_total_list])/num_samples;

figure(graph.(['f3',num2str(j)]));

subplot(2,4,i)
histogram(network_total_act_list,'normalization','probability')
grid on;
title([n_label,'s, AGC'],'interpreter','latex');
xlabel('\# of activations; $\Gamma$','interpreter','latex');
ylabel('$\textbf{P}[\Gamma]$','interpreter','latex')
ylim([0 0.2]);
% histogram(network_ufls_total_list,'normalization','probability')
% histogram(network_rocof_list,'normalization','probability')
% histogram(network_ofgs_list,'normalization','probability')

network_0rocof = network_rocof_list==0;
network_1rocof = network_rocof_list==1;
network_2rocof = network_rocof_list==2;
network_3rocof = network_rocof_list==3;
network_4rocof = network_rocof_list==4;

    network_rocof_categor_prob = sum([network_0rocof network_1rocof network_2rocof network_3rocof network_4rocof])/num_samples;
    
figure(graph.(['f4',num2str(j)]));
subplot(2,4,i)
bar(categorical({'0' '1' '2' '3' '4'}), network_rocof_categor_prob);
title([n_label,'s; AGC'],'interpreter','latex');
xlabel(' \# ROCOF: $\Gamma_{roc}$','interpreter','latex');
ylabel('$\textbf{P}[\Gamma_{roc}]$','interpreter','latex');
ylim([0, 0.2]);
grid on
    
network_0ufls = sum(network_ufls_total_list==0);
network_1ufls = sum(network_ufls_total_list==1);
network_2ufls = sum(network_ufls_total_list==2);
network_3ufls = sum(network_ufls_total_list==3);
network_4More_ufls = sum(network_ufls_total_list>3);
    network_ufls_categor_prob = [network_0ufls network_1ufls network_2ufls network_3ufls network_4More_ufls]/num_samples;
    
figure(graph.(['f5',num2str(j)]));
subplot(2,4,i)
bar(categorical({'0' '1' '2' '3' '>=4'}), network_ufls_categor_prob);
title([n_label,'s, AGC'],'interpreter','latex');
xlabel('\# UFLS: $\Gamma_{ufls}$','interpreter','latex');
ylabel('$\textbf{P}[\Gamma_{ufls}]$','interpreter','latex');
ylim([0,0.2])
grid on
    
end
figure(graph.f6)
subplot(1,length(dist_loc_list),j)
plot(agc_plot_list,network_average_act(j,:),'LineWidth',2)
title([chart_label],'interpreter','latex')
xlabel('AGC, s','interpreter','latex');
grid on
ylabel('$\mu(\Gamma)$','interpreter','latex')


G1= ['nodal activations ',chart_label,'.jpg'];
saveas(graph.(['f1',num2str(j)]),[exten,'/',G1]);
close(graph.(['f1',num2str(j)]));

G2= ['compare nodal activations ',chart_label,'.jpg'];
saveas(graph.(['f2',num2str(j)]),[exten,'/',G2]);
close(graph.(['f2',num2str(j)]));

G3= ['histograms of activations ',chart_label,'.jpg'];
saveas(graph.(['f3',num2str(j)]),[exten,'/',G3]);
close(graph.(['f3',num2str(j)]));

G4= ['rocof activations ',chart_label,'.jpg'];
saveas(graph.(['f4',num2str(j)]),[exten,'/',G4]);
close(graph.(['f4',num2str(j)]));

G5= ['ufls activations ',chart_label,'.jpg'];
saveas(graph.(['f5',num2str(j)]),[exten,'/',G5]);
close(graph.(['f5',num2str(j)]));
end


G6= ['Cascade vs AGC ',chart_label,'.jpg'];
saveas(graph.f6,[exten,'/',G6]);
close(graph.f6);

end